const mongoose = require('mongoose')


const mongoURI = "mongodb://localhost:27017/Mynotebook"

const connectToMongo = () => {
    mongoose.connect(mongoURI,{
        useNewUrlParser: true,
        useFindAndModify: false,
        useUnifiedTopology: true
      }).then(() => {
        console.log("connected");
    }).catch((error) => {
        console.log(error)
    })
    
}




module.exports = connectToMongo;